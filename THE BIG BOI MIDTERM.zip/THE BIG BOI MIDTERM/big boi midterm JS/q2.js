//div tag has 100 in it
// div tag needs to go down by 5 each click
//while loop would be good
// as long as it does not equal zero
//as long as something.innerHTML is > 0


let f = document.getElementById("five");

function
cinco()
{
   f.innerHTML -= 5;

// while(f.innerHTML > 83)
// {
//     f.innerHTML -=5;
// }

}