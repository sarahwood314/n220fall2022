//div tag
//will need a document get id thingy
//when clicked it needs to change from there to you to are
//two click for the test
// do not forget to call the function here
let w = document.getElementById("watcher");

let a = "you";

let b = "are";


function
see()
{  
    w.innerHTML = a;

    a = b;
    // if(w.innerHTML = "you")
    // {
    //     w.innerHTML = "are";
    // }

    // for(let i = 0; i < a.length; i++)
    // {
    //     w.inerHTML == a[i];
    // }
}

